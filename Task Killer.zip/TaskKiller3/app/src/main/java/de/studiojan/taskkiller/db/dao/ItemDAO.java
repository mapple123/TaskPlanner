package de.studiojan.taskkiller.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Update;

import de.studiojan.taskkiller.db.models.Item;


@Dao
public interface ItemDAO {

    /*@Query("SELECT * FROM items")
    LiveData<List<Item>> getAllItems();*/

    @Insert
    public void insert(Item... items);
    @Update
    public void update(Item... items);
    @Delete
    public void delete(Item item);
}
