package de.studiojan.taskkiller.db.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import androidx.annotation.NonNull;

@Entity(tableName = "items")
public class Item {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    private Long id;
    private String name;
    private String description;
    private Long quantity;

    public Item(String name){
        this.name = name;
    }

    @NonNull
    public Long getId() {
        return id;
    }

    public Long getQuantity() {
        return quantity;
    }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public void setId(@NonNull Long id) {
        this.id = id;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }
}
