package de.studiojan.taskkiller.db.item_helper;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

import de.studiojan.taskkiller.db.AppDatabase;
import de.studiojan.taskkiller.db.dao.ItemDAO;
import de.studiojan.taskkiller.db.models.Item;

public class ItemRepository {
    private ItemDAO itemDAO;
    private LiveData<List<Item>> allItems;

    public ItemRepository(Application application){
        AppDatabase database = AppDatabase.getDbInstance(application);
        itemDAO = database.getItemDAO();
        //allItems = itemDAO.getAllItems();
    }

    public void insert(Item item){
        new InsertItemAsyncTask(itemDAO).execute(item);
    }

    public void update(Item item){
        new UpdateItemAsyncTask(itemDAO).execute(item);
    }
    public void delete(Item item){
        new DeleteItemAsyncTask(itemDAO).execute(item);
    }

    public LiveData<List<Item>> getAllItems(){
        return allItems;
    }

    private static class InsertItemAsyncTask extends AsyncTask<Item, Void, Void>{

        private ItemDAO itemDAO;

        private InsertItemAsyncTask(ItemDAO itemDAO){
            this.itemDAO = itemDAO;
        }
        @Override
        protected Void doInBackground(Item... items) {
            itemDAO.insert(items[0]);
            return null;
        }
    }

    private static class DeleteItemAsyncTask extends AsyncTask<Item, Void, Void>{

        private ItemDAO itemDAO;

        private DeleteItemAsyncTask(ItemDAO itemDAO){
            this.itemDAO = itemDAO;
        }
        @Override
        protected Void doInBackground(Item... items) {
            itemDAO.delete(items[0]);
            return null;
        }
    }

    private static class UpdateItemAsyncTask extends AsyncTask<Item, Void, Void>{

        private ItemDAO itemDAO;

        private UpdateItemAsyncTask(ItemDAO itemDAO){
            this.itemDAO = itemDAO;
        }
        @Override
        protected Void doInBackground(Item... items) {
            itemDAO.update(items[0]);
            return null;
        }
    }
}
