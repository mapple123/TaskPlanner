package de.studiojan.taskkiller.db.item_helper;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import de.studiojan.taskkiller.R;
import de.studiojan.taskkiller.db.models.Item;


public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.MyViewHolder> {

    private Context context;
    private List<Item> itemList = new ArrayList<>();

    public ItemListAdapter(Context context){
        this.context = context;
    }
    public void setItemList(List<Item> itemList){
        this.itemList = itemList;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_row, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.txtViewName.setText(this.itemList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return this.itemList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView txtViewName;
        public MyViewHolder(View view){
            super(view);
             txtViewName = view.findViewById(R.id.textViewName);
        }
    }
}
